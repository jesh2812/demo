import './App.css';
import React,{useEffect, Suspense} from 'react';
import { Routes,Route, useNavigate, useLocation } from 'react-router-dom';
import { Link } from 'react-router-dom';
import LoginPage from './components/pages/LoginPage';
import { actions } from "./components/utils/dataCenter";
import {useDispatch} from 'react-redux';
import { Tooltip } from '@chakra-ui/react'
import { Avatar} from '@chakra-ui/react'
import { WrapItem } from '@chakra-ui/react'
import {Menu,MenuButton,MenuList,MenuItem,} from '@chakra-ui/react'
import Existing_Template from './components/templates/Existing_Template/Existing_Template'
import New_Template from './components/templates/New_Template';
import useLogin from './components/Login/useLogin'
import ModuleTemplate from './components/templates/ModuleTemplate/ModuleTemplate'
import EditModuleTemplate from './components/templates/ModuleTemplate/EditModuleTemplate';
import LandingPage from "./components/pages/LandingPage"
const EditTemplate = React.lazy(() => import("./components/templates/EditTemplate"));


function App() {
  const dispatch=useDispatch();
  const navigate=useNavigate();
  const location = useLocation();
  //const { isLoggedIn, userName, login, logout } = useLogin();
  const terraformLoginObj = useLogin({
    module: "terraform",
    url: "/login",
  });
  const { isLoggedIn, userName, login, logout } = terraformLoginObj;
  
  useEffect(() => {
    if(location.pathname==='/'){
      navigate('/home')
    }
  }, [location])

  return (
    <div className='app'>
      <div id='div1' className='app-header_container'>
        <img src='https://www.tigeranalytics.com/wp-content/uploads/logo.png' alt="Tiger Analytics" />
        <h1 className='header' style={{ fontSize:"30px",fontWeight:"bold" }}>Tiger DataOps</h1>
        <div className='login-profile'>
          {isLoggedIn&&(
            <Link to={'/templates'} onClick={()=>{dispatch(actions.deleteAll())}}>
              <button className='home-button'><i class="fa-solid fa-house"></i></button>
            </Link>)}
          {isLoggedIn&&
            
            <Menu>
            <MenuButton aria-label='Options' >
                <WrapItem className='last' >
                  <Tooltip label={userName} fontSize='md'>
                    <Avatar name={userName} src='https://bit.ly/tioluwani-kolawole'>
                    </Avatar>
                  </Tooltip>
                </WrapItem>
            </MenuButton>
            <MenuList>
              <MenuItem>
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <button className="logout-button" onClick={logout}>Log Out</button>
              </MenuItem>
            </MenuList>
          </Menu>
          }
          
        </div>
      </div>
      <div>
        <Routes>
          {!isLoggedIn&&<Route path={'/login'} element={<LoginPage isLoggedIn={isLoggedIn} login={login}/>}/>}
          ?{!isLoggedIn&&<Route path={'*'} element={<LoginPage isLoggedIn={isLoggedIn} login={login} />} />}
          {/* isLoggedIn&&<Route path='/' element={<Existing_Template/>}></Route> */}
          {isLoggedIn&&<Route path='/templates'>
            <Route index element={<Existing_Template/>}/>
            <Route path={'newTemplate'} element={<New_Template/>}/>
            <Route path={'existingTemplate'} element={<Existing_Template/>}/>
            <Route path={'editTemplate/:name'} element={<Suspense><EditTemplate/></Suspense>}/>
            <Route path={'editModule/:name'} element={<EditModuleTemplate/>} />
          </Route>}
          {isLoggedIn && <Route path="/home" element={<LandingPage/>}/>}
          {isLoggedIn && <Route path="/newModule" element={<ModuleTemplate/>}/>}
        </Routes>
      </div>
    </div>


  );
}

export default App;

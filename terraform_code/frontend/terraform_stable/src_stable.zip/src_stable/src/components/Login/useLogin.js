import React from "react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import AxiosInstance from "../utils/AxiosInstance";

const useLogin = () => {
  const [isLoggedIn, setLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    if (sessionStorage.getItem("isLoggedIn")) {
      setLoggedIn(true);
      setUserName(sessionStorage.getItem("userName"));
    }
  }, []);

  const login = async (email, password) => {
    const response = await AxiosInstance.post("/login", {
      email: email,
      password: password,
    });

    const data = response.data;

    //const data = "Success";
    if (data === "Success") {
      setLoggedIn(true);
      setUserName(email);
      sessionStorage.setItem("isLoggedIn", true);
      sessionStorage.setItem("userName", userName);

      navigate("/home");
    } else {
      console.log("error");
      //error
    }
  };

  const logout = () => {
    setLoggedIn(false);
    sessionStorage.removeItem("isLoggedIn");
    sessionStorage.removeItem("userName");
    setUserName(null);
    navigate("/home");
  };

  return { isLoggedIn, userName, login, logout };
};

export default useLogin;

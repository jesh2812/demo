import axios from "axios";

const AxiosInstance = axios.create({
  baseURL: "/api",
  headers: { "Content-Type": "application/json" },
});
//http://localhost:5000

export default AxiosInstance;

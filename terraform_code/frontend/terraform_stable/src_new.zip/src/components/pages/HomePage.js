import React from "react";
import {useHistory} from 'react-router-dom'
function HomePage(){
    
    return(
        <div className="home">
            <button>Manage Terraform Scripts</button>
        </div>
    )
}
export default HomePage;
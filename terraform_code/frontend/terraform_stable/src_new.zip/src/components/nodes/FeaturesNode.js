export const FeaturesNode=({data})=>{
    return (<div>
{data.label}
    </div>)
}
 
export const nodeTypes = {
    featuresNode:FeaturesNode
}
